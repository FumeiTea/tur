PATH+=:/opt/sh/
