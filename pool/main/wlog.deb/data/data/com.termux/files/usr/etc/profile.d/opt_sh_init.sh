PATH+=$PATH:/opt/sh/
